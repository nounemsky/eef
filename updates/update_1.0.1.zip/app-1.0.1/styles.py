# Темы оформления
THEMES = {
    "Dark Theme": {
        "background": "#141414",
        "text": "#ffffff",
        "accent": "#27ae60",
        "button": "#3c3f41",
        "button_hover": "#2ecc71",
        "border": "#444444"
    },
    "Light Theme": {
        "background": "#ffffff",
        "text": "#000000",
        "accent": "#27ae60",
        "button": "#f0f0f0",
        "button_hover": "#e5e5e5",
        "border": "#d0d0d0"
    },
    "Midnight Blue": {
        "background": "#1a1b2e",
        "text": "#e4e4e4",
        "accent": "#4a9eff",
        "button": "#2d2d44",
        "button_hover": "#373751",
        "border": "#373751"
    },
    "Forest Green": {
        "background": "#1e2b1e",
        "text": "#e4e4e4",
        "accent": "#4caf50",
        "button": "#2d3b2d",
        "button_hover": "#374837",
        "border": "#374837"
    }
}

def get_theme_styles(theme_name):
    theme = THEMES.get(theme_name, THEMES["Dark Theme"])
    
    return f"""
    QMainWindow, QDialog {{
        background-color: {theme["background"]};
        color: {theme["text"]};
    }}
    
    QPushButton {{
        background-color: {theme["button"]};
        color: {theme["text"]};
        border: 1px solid {theme["border"]};
        padding: 8px 16px;
        border-radius: 4px;
        font-size: 14px;
    }}
    
    QPushButton:hover {{
        background-color: {theme["button_hover"]};
    }}
    
    QPushButton:pressed {{
        background-color: {theme["accent"]};
    }}
    
    QLineEdit, QTextEdit, QComboBox {{
        background-color: {theme["button"]};
        color: {theme["text"]};
        border: 1px solid {theme["border"]};
        padding: 5px;
        border-radius: 4px;
    }}
    
    QLabel {{
        color: {theme["text"]};
    }}
    """

# Основные стили приложения
APP_STYLES = """
#MainContainer {
    background-color: rgba(20, 20, 20, 253);
    border-radius: 8px;
    border: 1px solid #3a3a3a;
    box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.1); /* Легкая тень */
}

#CentralWidget {
    background-color: #141414;
    border-top: 1px solid #444;
    border-radius: 0px;
}

#TagsContainer {
    background: #1E1E1E !important;
    border-radius: 4px !important;
    padding: 8px !important;
}

#LeftPanel {
    border-right: 1px solid #444;
    border-top: 1px solid #444;
    background-color: #141414;
}

QSplitter::handle {
    background: #444;
    width: 1px;
    height: 1px;
}

QSplitter::handle:hover {
    background: #FFFFFF;
}

QSplitter::handle:pressed {
    background: #FFFFFF;
}

#RightPanel {
    border-left: 1px solid #444;
    border-top: 1px solid #444;
    background-color: #141414;
}

QLabel { 
    color: #ffffff; 
    font-size: 16px; 
}

QLineEdit {
    background-color: #3c3f41; 
    color: #ffffff;
    border: 1px solid #606060;
    border-radius: 4px; 
    padding: 5px;
}

QListWidget, QComboBox {
    background-color: #3c3f41; 
    color: #ffffff;
    border: 1px solid #555555; 
    border-radius: 4px;
    padding: 5px;
}

QPushButton {
    background-color: #27ae60; 
    color: white;
    border: none;
    padding: 8px 16px;
    border-radius: 4px;
    font-size: 14px;
    transition: all 0.3s ease-in-out; /* Плавный переход */
    box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2); /* Легкая тень */
}

QPushButton:hover {
    background-color: #2ecc71; 
    transform: scale(1.05); /* Увеличение при наведении */
    box-shadow: 0px 6px 15px rgba(0, 0, 0, 0.3); /* Увеличенная тень при наведении */
}

QPushButton:pressed {
    background-color: #27ae60; 
    transform: scale(0.95); /* Немного сжимаем кнопку при нажатии */
}

QProgressBar {
    background-color: rgba(250, 250, 250, 10);
    border: none;
    border-radius: 0px;
}

QProgressBar::chunk {
    background-color: #2ecc71;
}

#closeButton, #minimizeButton, #maximizeButton {
    border: none;
    border-radius: 8px; /* 18/2 = круглая кнопка */
    width: 16px;
    height: 16px;
}

#closeButton {
    background-color: #ff5f57;
}

#closeButton:hover {
    background-color: #ff3b30;
}

#minimizeButton {
    background-color: #febc2e;
}

#minimizeButton:hover {
    background-color: #fea500;
}

#maximizeButton {
    background-color: #28c940;
}

#maximizeButton:hover {
    background-color: #1d9d30;
}

#passwordList {
    alternate-background-color: #2a2a2a;
}
"""



# Стили для генератора паролей
PASSWORD_STYLES = """
QDialog {
    background-color: #121212;
    border: 1px solid #3D3D3D;
    border-radius: 10px;
    color: white;
}

QLabel, QCheckBox {
    color: white;
    font-size: 13px;
}

QLineEdit {
    background-color: #1e1e1e;
    color: white;
    border: 1px solid #555;
    padding: 4px;
    border-radius: 4px;
}

QSpinBox {
    background-color: #1e1e1e;
    color: white;
    border: 1px solid #555;
    border-radius: 4px;
}

QPushButton {
    background-color: #333;
    color: white;
    padding: 5px 10px;
    border-radius: 4px;
}

QPushButton:hover {
    background-color: #444;
}
"""

# Стили для поиска
SEARCH_STYLES = """
QLineEdit {
    background-color: #2D2D2D;
    border: 1px solid #404040;
    border-radius: 5px;
    padding: 3px 12px;
    color: #FFFFFF;
    font-size: 13px;
    min-width: 250px;
}

QLineEdit:focus {
    border: 1px solid #5E5E5E;
    background-color: #2D2D2D;
}
"""


# Стили для заметок
NOTES_STYLES = """
QTextEdit {
    background-color: #2d2d2d;
    border: 1px solid #3D3D3D;
    border-radius: 5px;
    padding: 5px;
    font-family: 'Segoe UI', Arial, sans-serif;
    font-size: 14px;
    color: #FFFFFF;
}
"""

# Стили для статуса пароля
PASSWORD_STATUS_STYLES = """
QLabel {
    padding: 2px 6px;
    border-radius: 2px;
    font-size: 11px;
}
"""

# Стили для окна аутентификации
AUTH_STYLES = """
QWidget {
    background-color: #141414;
}

QLabel {
    color: #ffffff;
    font-size: 20px;
    font-weight: bold;
}

QLineEdit {
    background-color: #1C1C1E;
    color: #ffffff;
    border: 1px solid #3D3D3D;
    border-radius: 4px;
    padding: 6px 10px;
    font-size: 13px;
    min-height: 20px;
}

QLineEdit:focus {
    border: 1px solid #606060;
}
"""
